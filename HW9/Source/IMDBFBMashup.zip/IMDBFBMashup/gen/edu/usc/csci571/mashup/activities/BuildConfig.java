/** Automatically generated file. DO NOT MODIFY */
package edu.usc.csci571.mashup.activities;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}