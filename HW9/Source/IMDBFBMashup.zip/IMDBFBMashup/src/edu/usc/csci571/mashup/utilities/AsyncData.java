/**
 * 
 */
package edu.usc.csci571.mashup.utilities;

/**
 * This is a marker interface to indicate the data fetched after an async task
 * @author mohit.aggarwal
 *
 */
public interface AsyncData {

}
